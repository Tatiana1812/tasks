package builders;

/**
 * Ошибка тестирования билдера
 * @author alexeev
 */
public class BuilderTestException extends Exception {
  public BuilderTestException(String msg) {
    super(msg);
  }
}
