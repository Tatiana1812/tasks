package gui;

/**
 * Listener of application settings change.
 * @author alexeev
 */
public interface i_AppSettingsChangeListener {
  void settingsChanged();
}
