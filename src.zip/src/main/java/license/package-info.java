/**
 * Provides the classes for copyright protection.
 */
package license;