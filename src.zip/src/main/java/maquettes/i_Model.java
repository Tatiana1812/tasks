package maquettes;

/**
 * @author Leonid Ivanovsky
 */

public interface i_Model {

    public void sculptModels();

    public Cover getCover();

}
