package maquettes;

/**
 * Enumerator for mesh file types
 * @author Vladimir
 */
public enum MeshFileType {
    PLY,
    STL,
    OBJ
}
