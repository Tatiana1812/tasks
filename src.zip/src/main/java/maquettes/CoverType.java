package maquettes;

/**
 *
 * @author Vladimir
 */
public enum CoverType {

  ARC,
  CIRCLE,
  CONE,
  CYLINDER,
  EDGE,
  FACE,
  POINT,
  IMPORT
}
