package maquettes;

/**
 * @author Leonid Ivanovsky
 */

/**
 * Phases of cover's generating
 */

public interface i_GeneratedCover {

    public void buildPointCover();

    public void buildTriangularCover();

}
