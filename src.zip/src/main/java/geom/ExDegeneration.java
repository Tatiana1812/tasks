package geom;

public class ExDegeneration extends ExGeom {
  public ExDegeneration( String message ){
    super(message);
  }
};
