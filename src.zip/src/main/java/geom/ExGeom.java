package geom;

public class ExGeom extends Exception {
  private static final long serialVersionUID = 1L;

  public ExGeom( String message ){
    super(message);
  }
};
