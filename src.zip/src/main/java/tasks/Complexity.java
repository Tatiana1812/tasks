package tasks;

public enum Complexity {
    EASY,
    MEDIUM,
    HARD
}
