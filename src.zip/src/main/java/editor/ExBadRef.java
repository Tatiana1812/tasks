package editor;

public class ExBadRef extends Exception {
  private static final long serialVersionUID = 1L;

  public ExBadRef( String message ){
    super(message);
  }
};
