package editor;

/**
 *
 * @author alexeev
 */
public interface i_Identifiable {
  public String id();
}
