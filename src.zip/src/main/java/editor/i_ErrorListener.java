package editor;

/**
 * Listener of error messages.
 * 
 * @author alexeev
 */
public interface i_ErrorListener {
  public void handleError(String msg);
}
